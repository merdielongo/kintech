@extends('layouts.default')

@section('content')

<div class="container mt-5">
    {!! Form::open() !!}
    <div class="p-5 shadow-sm row card">
        <center><h5><b>Enregistrez-vous</b> <br> pour participer en tant que visiteur</h5></center>

        <div class="mt-5 row">
            <div class="mb-3 form-group col-lg-4">
                <b>{!! Form::label('Nom') !!}</b>
                {!! Form::text('name', null, ['class'=> 'form-control']) !!}
            </div>

            <div class="mb-3 form-group col-lg-4">
                <b>{!! Form::label('Post Nom') !!}</b>
                {!! Form::text('project', null, ['class'=> 'form-control']) !!}
            </div>

            <div class="mb-3 form-group col-lg-4">
                <b>{!! Form::label('Prénom') !!}</b>
                {!! Form::text('project', null, ['class'=> 'form-control']) !!}
            </div>

            <div class="mb-3 form-group col-lg-4">
                <b>{!! Form::label('Sexe') !!}</b>
                {!! Form::select('sex', ['h'=>'homme', 'f' =>'femme'], 'h', ['class'=> 'form-control']) !!}
                {{-- {!! Form::text('project', null, ['class'=> 'form-control']) !!} --}}
            </div>

            <div class="mb-3 form-group col-lg-4">
                <b>{!! Form::label('Adresse email') !!}</b>
                {!! Form::text('project', null, ['class'=> 'form-control']) !!}
            </div>

            <div class="mb-3 form-group col-lg-4">
                <b>{!! Form::label('Numero de telephone') !!}</b>
                {!! Form::text('project', null, ['class'=> 'form-control']) !!}
            </div>
        </div>

        <div class="mt-4 row">
            {!! Form::submit('S\'inscrire', ['class'=>'btn btn-info col-lg-4 col-md-4']) !!}
        </div>

    </div>
    {!! Form::close() !!}
</div>

@endsection
