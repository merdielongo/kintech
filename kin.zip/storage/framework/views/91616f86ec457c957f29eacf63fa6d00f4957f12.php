<br><br><br>
<div class="pt-5 pb-5 bg-white">
    <div class="container pt-5 pb-5">
        <div class="row">
            <div class="col-lg-3 col-md-3">
                <ul class="list-group">
                    <li class="nav-item"><a href="#" class="font-bold nav-link text-danger text-uppercase">Navigation</a></li><br>
                    <li class="nav-item"><a href="#" class="nav-link text-dark text-uppercase">Accueil</a></li>
                    <li class="nav-item"><a href="#" class="nav-link text-dark text-uppercase">Evenement</a></li>
                    <li class="nav-item"><a href="#" class="nav-link text-dark text-uppercase">Concours</a></li>
                    <li class="nav-item"><a href="#" class="nav-link text-dark text-uppercase">A propos</a></li>
                </ul>
            </div>

            <div class="col-lg-3 col-md-3">
                <ul class="list-group">
                    <li class="nav-item"><a href="#" class="font-bold nav-link text-danger text-uppercase">Support</a></li><br>
                    <li class="nav-item"><a href="#" class="nav-link text-dark text-uppercase">FAQ</a></li>
                    <li class="nav-item"><a href="#" class="nav-link text-dark text-uppercase">Comment ça fonctionne</a></li>
                    <li class="nav-item"><a href="#" class="nav-link text-dark text-uppercase">Inscription</a></li>
                    <li class="nav-item"><a href="#" class="nav-link text-dark text-uppercase">Contact</a></li>
                </ul>
            </div>

            <div class="col-lg-3 col-md-3">
                <ul class="list-group">
                    <li class="nav-item"><a class="font-bold nav-link text-danger text-uppercase">Contactez nous</a></li><br>
                    <li class="nav-item"><a class="nav-link text-dark text-uppercase">+243 000 000 00</a></li>
                    <li class="nav-item"><a class="nav-link text-dark text-uppercase">support@kintech.com</a></li>
                    <li class="nav-item"><a class="nav-link text-dark text-uppercase">mon adresse, c. commune, q. quartier</a></li>
                    <li class="nav-item"><a class="nav-link text-dark text-uppercase">kinshasa</a></li>
                </ul>
            </div>

            <div class="col-lg-3 col-md-3">
                <ul class="list-group">
                    <li class="nav-item"><a href="#" class="font-bold nav-link text-danger text-uppercase">Suivez nous sur</a></li><br>
                    <li class="nav-item"><a href="#" class="nav-link text-dark text-uppercase">Facebook</a></li>
                    <li class="nav-item"><a href="#" class="nav-link text-dark text-uppercase">Twitter</a></li>
                    <li class="nav-item"><a href="#" class="nav-link text-dark text-uppercase">Instagram</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>


<div class="pt-2 pb-2 text-white" style="background: #A3386D">
    <div class="container pt-2 pb-2">
        <div class="row">
            <center><span class="font-semibold text-md">copyright &copy; 2021 all rights reserved design by <a href="#">Credo creation</a></span></center>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\kintech-v2\resources\views/includes/navigation-bottom.blade.php ENDPATH**/ ?>