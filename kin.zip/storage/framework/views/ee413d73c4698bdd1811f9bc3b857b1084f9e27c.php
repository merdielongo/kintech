<br><br><br>
<div class="pt-5 pb-5 bg-white">
    <div class="container pt-5 pb-5">
        <div class="row">
            <div class="col-lg-3 col-md-3">
                <ul class="list-group">
                    <li class="nav-item"><a href="#" class="font-bold nav-link text-danger text-">Navigation</a></li><br>
                    <li class="nav-item"><a href="#" class="nav-link text-dark text-">Accueil</a></li>
                    <li class="nav-item"><a href="#" class="nav-link text-dark text-">Evenement</a></li>
                    <li class="nav-item"><a href="#" class="nav-link text-dark text-">Concours</a></li>
                    <li class="nav-item"><a href="#" class="nav-link text-dark text-">A propos</a></li>
                </ul>
            </div>

            <div class="col-lg-3 col-md-3">
                <ul class="list-group">
                    <li class="nav-item"><a href="#" class="font-bold nav-link text-danger text-">Support</a></li><br>
                    <li class="nav-item"><a href="#" class="nav-link text-dark text-">FAQ</a></li>
                    <li class="nav-item"><a href="#" class="nav-link text-dark text-">Comment ça fonctionne</a></li>
                    <li class="nav-item"><a href="#" class="nav-link text-dark text-">Inscription</a></li>
                    <li class="nav-item"><a href="#" class="nav-link text-dark text-">Contact</a></li>
                </ul>
            </div>

            <div class="col-lg-3 col-md-3">
                <ul class="list-group">
                    <li class="nav-item"><a class="font-bold nav-link text-danger text-">Contactez nous</a></li><br>
                    <li class="nav-item"><a class="nav-link text-dark text-">+243 000 000 00</a></li>
                    <li class="nav-item"><a class="nav-link text-dark text-">Kintech@kinshasa.gouv.cd</a></li>
                    <li class="nav-item"><a class="nav-link text-dark text-">mon adresse, c. commune, q. quartier</a></li>
                    <li class="nav-item"><a class="nav-link text-dark text-">kinshasa</a></li>
                </ul>
            </div>

            <div class="col-lg-3 col-md-3">
                <ul class="list-group">
                    <li class="nav-item"><a href="#" class="font-bold nav-link text-danger text-">Suivez nous sur</a></li><br>
                    <li class="nav-item"><a href="#" class="nav-link text-dark text-">Facebook</a></li>
                    <li class="nav-item"><a href="#" class="nav-link text-dark text-">Twitter</a></li>
                    <li class="nav-item"><a href="#" class="nav-link text-dark text-">Instagram</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>


<div class="pt-2 pb-2 text-white" style="background: #A3386D">
    <div class="container pt-2 pb-2">
        <div class="row">
            <center><span class="font-semibold text-md">copyright &copy; 2021 all rights reserved design by <a href="#">Credo creation</a></span></center>
        </div>
    </div>
</div>
<?php /**PATH /opt/lampp/htdocs/app/resources/views/includes/navigation-bottom.blade.php ENDPATH**/ ?>