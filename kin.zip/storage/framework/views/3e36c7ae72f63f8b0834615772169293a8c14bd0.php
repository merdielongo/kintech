<nav class="bg-white shadow-sm navbar navbar-expand-lg navbar-light fixed-top">
    <div class="container">
        <a class="navbar-brand" href="<?php echo e(route('home.index')); ?>">
            <img src="<?php echo e(asset('img/thumb/logo.svg')); ?>" alt="" width="80" height="74">
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="mb-2 navbar-nav ms-auto mb-lg-0">
                <li class="nav-item"><a class="nav-link active" aria-current="page" href="<?php echo e(route('home.index')); ?>">Accueil</a></li>
                <li class="nav-item"><a class="nav-link" aria-current="page" href="<?php echo e(route('home.event')); ?>">Evénement</a></li>
                <li class="nav-item"><a class="nav-link" aria-current="page" href="<?php echo e(route('home.exposition')); ?>">Devenir Exposant</a></li>
                <li class="nav-item"><a class="nav-link" aria-current="page" href="<?php echo e(route('home.sponsor')); ?>">Devenir sponsors</a></li>
                <li class="nav-item"><a class="nav-link" aria-current="page" href="<?php echo e(route('home.concours')); ?>">Concours</a></li>
                <li class="nav-item"><a class="nav-link" aria-current="page" href="<?php echo e(route('home.contact')); ?>">Contact</a></li>
                <li class=""><a class="p-2 shadow-sm ms-5 btn btn-primary rounded-pill" aria-current="page" href="<?php echo e(route('home.register')); ?>">Participez !</a></li>
            </ul>
        </div>
    </div>
</nav>
<br><br><br><br>
<?php /**PATH /home/tcvo5855/sites/KinTech-v2/resources/views/includes/navigation.blade.php ENDPATH**/ ?>