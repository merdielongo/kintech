<?php $__env->startSection('content'); ?>

<div class="container mt-5">
    <?php echo Form::open(); ?>

    <div class="p-5 shadow-sm row card">

        <div class="mt-5 row">

            <div class="col-lg-6 col-md-6">
                <img src="<?php echo e(asset('img/thumb/WhatsApp Image 2021-08-29 at 15.04.00.jpeg')); ?>" alt="" class="w-100">
            </div>
            <div class="col-lg-6 col-md-6">
                    <h5 class="mb-4 text-md">Contactez nous pour plus d'infos</h5>
                    <div class="mb-3 form-group">
                        <b><?php echo Form::label('Nom '); ?></b>
                        <?php echo Form::text('name', null, ['class'=> 'form-control']); ?>

                    </div>

                    <div class="mb-3 form-group">
                        <b><?php echo Form::label('Adresse email'); ?></b>
                        <?php echo Form::text('project', null, ['class'=> 'form-control']); ?>

                    </div>

                    <div class="mb-3 form-group">
                        <b><?php echo Form::label('Message'); ?></b>
                        
                        <?php echo Form::textarea('project', null, ['class'=> 'form-control']); ?>

                    </div>
                    <?php echo Form::submit('Envoyer le formulaire', ['class'=>'btn btn-danger col-lg-4 col-md-4']); ?>


                </div>
            </div>


    </div>
    <?php echo Form::close(); ?>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/app/resources/views/pages/contact.blade.php ENDPATH**/ ?>