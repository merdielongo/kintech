<?php $__env->startSection('content'); ?>

<div class="container mt-5">
    <?php echo Form::open(); ?>

    <div class="p-5 shadow-sm row card">
        <center><h5><b>Enregistrez-vous</b> <br> pour participer en tant que visiteur</h5></center>

        <div class="mt-5 row">
            <div class="mb-3 form-group col-lg-4">
                <b><?php echo Form::label('Nom'); ?></b>
                <?php echo Form::text('name', null, ['class'=> 'form-control']); ?>

            </div>

            <div class="mb-3 form-group col-lg-4">
                <b><?php echo Form::label('Post Nom'); ?></b>
                <?php echo Form::text('project', null, ['class'=> 'form-control']); ?>

            </div>

            <div class="mb-3 form-group col-lg-4">
                <b><?php echo Form::label('Prénom'); ?></b>
                <?php echo Form::text('project', null, ['class'=> 'form-control']); ?>

            </div>

            <div class="mb-3 form-group col-lg-4">
                <b><?php echo Form::label('Sexe'); ?></b>
                <?php echo Form::select('sex', ['h'=>'homme', 'f' =>'femme'], 'h', ['class'=> 'form-control']); ?>

                
            </div>

            <div class="mb-3 form-group col-lg-4">
                <b><?php echo Form::label('Adresse email'); ?></b>
                <?php echo Form::text('project', null, ['class'=> 'form-control']); ?>

            </div>

            <div class="mb-3 form-group col-lg-4">
                <b><?php echo Form::label('Numero de telephone'); ?></b>
                <?php echo Form::text('project', null, ['class'=> 'form-control']); ?>

            </div>
        </div>

        <div class="mt-4 row">
            <?php echo Form::submit('S\'inscrire', ['class'=>'btn btn-info col-lg-4 col-md-4']); ?>

        </div>

    </div>
    <?php echo Form::close(); ?>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kintech-v2\resources\views/pages/register.blade.php ENDPATH**/ ?>