<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="mt-5 row">
        <div class="mt-5 col-lg-6 col-md-6">
            <div class="fw-bold text-uppercase">
                KINTECH <br>
                Edition 2021
            </div>

            <div class="mt-4 text-uppercase fs-2">
                Des rencontres à <br>
                ne pas manquer
            </div>

            <div class="mt-5 row">
                <div class="col-lg-6 col-md-6">
                    <a href="<?php echo e(route('home.register')); ?>" class="p-2 text-lg rounded-pill btn btn-primary w-100">Inscrivez vous</a>
                </div>

                
            </div>
        </div>

        <div class="mt-5 col-lg-6 col-md-6">
            <span class="fw-normal fs-5">KINTECH, première foire du numérique organisée par la ville de Kinshasa</span>
            <div class="mt-3 row">
                <div class="col-lg-12">
                    <div class="flex-row p-3 mb-2 border-0 card d-flex">
                        <div class="text-success fas fa-check-circle fa-2x pe-4"></div>
                        <div class="fw-bold">2 jours d’évènement</div>
                    </div>

                    <div class="flex-row p-3 mb-2 border-0 card d-flex">
                        <div class="text-success fas fa-check fa-2x pe-4"></div>
                        <div class="fw-bold">4 grandes conférences</div>
                    </div>

                    <div class="flex-row p-3 mb-2 border-0 card d-flex">
                        <div class="text-success fas fa-check-circle fa-2x pe-4"></div>
                        <div class="fw-bold">Des rencontres entre développeurs, start-ups et décideurs du secteur numérique</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="p-3 mt-5 bg-white">
    <div class="p-5 row">
        <center>
            <div class="fs-4">
                <span>Des solutions</span>
                <span>numeriques pour</span> <br> la <b>ville de KINSHASA</b>
            </div>
        </center>
    </div>
</div>

<div class="text-white" style="background: #8D3D89">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-3">
                <img src="<?php echo e(asset('img/thumb/logo.svg')); ?>" alt="" class="w-100">
            </div>

            <div class="col-lg-6 col-md-6 d-flex align-items-center">
                <p class="fs-4"><b>KINTECH</b>, c’est l’ambition de devenir le premier partenaire de l’entrepreneuriat numérique à Kinshasa.</p>
            </div>
        </div>
    </div>
</div>


<div class="container mt-3 mb-4">
    <div class="row">

        <div class="p-5 row">
            <center>
                <div class="fs-4">
                    <span>Participez à l’aventure</span>
                    <span><b>KINTECH !</b></span>
                </div>
            </center>
        </div>

        <div class="mb-4 col-lg-3 col-md-3 offset-lg-1 offset-md-1">
            <div class="p-5 shadow-sm card">
                <div class="img-card-top">
                    <img src="<?php echo e(asset('img/thumb/project.svg')); ?>" alt="" class="w-100">
                </div>

                <div class="text-center card-content">
                    <p class="mt-5 fw-bold"><br> Devenez sponsors <br><br> <br></p>
                    <a href="#" class="btn btn-danger">En savoir plus</a>
                </div>
            </div>
        </div>

        <div class="mb-4 col-lg-3 col-md-3">
            <div class="p-5 shadow-sm card">
                <div class="img-card-top">
                    <img src="<?php echo e(asset('img/thumb/project.svg')); ?>" alt="" class="w-100">
                </div>

                <div class="text-center card-content">
                    <p class="mt-5 fw-bold">Inscrivez –vous en ligne gratuitement et participez à l’évènement en tant que visiteur </p>
                    <a href="#" class="btn btn-danger">En savoir plus</a>
                </div>
            </div>
        </div>

        <div class="mb-4 col-lg-3 col-md-3">
            <div class="p-5 shadow-sm card">
                <div class="img-card-top">
                    <img src="<?php echo e(asset('img/thumb/project.svg')); ?>" alt="" class="w-100">
                </div>

                <div class="text-center card-content">
                    <p class="mt-5 fw-bold">Devenez exposant. <br> <br><br> <br> </p>
                    <a href="#" class="btn btn-danger">En savoir plus</a>
                </div>
            </div>
        </div>


    </div>
</div>


<div class="pt-5 pb-5">
    <div class="container pt-2 pb-2">
        <div class="row">
            <center>
                <span>EDITION 2021</span> <br>
                <span class="text-3xl font-bold">Intervenants</span>
            </center>
        </div><br><br><br>

        <div class="row">
            <div class="mb-5 col-lg-3 col-md-3">
                <div id="card-intervenant">
                    <div class="border-0 card rounded-2xl">
                        <img style="height: 270px;" src="" class="card-img-top card rounded-2xl" alt="...">
                    </div>

                    <div class="mt-2 border-0 card rounded-2xl">
                        <div class="card-body">
                            <h5 class="font-bold text-center card-title">Christian Buehner</h5>
                            <p class="text-center card-text"><b>Expériences :</b> mon expérience + nombres d'années d'exercice </p>
                        </div>
                        <div class="p-1 rounded-b-2xl" style="background: #8D3D89"></div>
                        </div>
                </div>
            </div>

            <div class="mb-5 col-lg-3 col-md-3">
                <div id="card-intervenant">
                    <div class="border-0 card rounded-2xl">
                        <img style="height: 270px;" src="" class="card-img-top card rounded-2xl" alt="...">
                    </div>

                    <div class="mt-2 border-0 card rounded-2xl">
                        <div class="card-body">
                            <h5 class="font-bold text-center card-title">Christian Buehner</h5>
                            <p class="text-center card-text"><b>Expériences :</b> mon expérience + nombres d'années d'exercice </p>
                        </div>
                        <div class="p-1 rounded-b-2xl" style="background: #8D3D89"></div>
                        </div>
                </div>
            </div>

            <div class="mb-5 col-lg-3 col-md-3">
                <div id="card-intervenant">
                    <div class="border-0 card rounded-2xl">
                        <img style="height: 270px;" src="" class="card-img-top card rounded-2xl" alt="...">
                    </div>

                    <div class="mt-2 border-0 card rounded-2xl">
                        <div class="card-body">
                            <h5 class="font-bold text-center card-title">Christian Buehner</h5>
                            <p class="text-center card-text"><b>Expériences :</b> mon expérience + nombres d'années d'exercice </p>
                        </div>
                        <div class="p-1 rounded-b-2xl" style="background: #8D3D89"></div>
                        </div>
                </div>
            </div>

            <div class="mb-5 col-lg-3 col-md-3">
                <div id="card-intervenant">
                    <div class="border-0 card rounded-2xl">
                        <img style="height: 270px;" src="" class="card-img-top card rounded-2xl" alt="...">
                    </div>

                    <div class="mt-2 border-0 card rounded-2xl">
                        <div class="card-body">
                            <h5 class="font-bold text-center card-title">Christian Buehner</h5>
                            <p class="text-center card-text"><b>Expériences :</b> mon expérience + nombres d'années d'exercice </p>
                        </div>
                        <div class="p-1 rounded-b-2xl" style="background: #8D3D89"></div>
                        </div>
                </div>
            </div>
        </div>
    </div>
</div>


<div style="background: #8D3D89" class="pt-5 pb-5">
    <div class="container pt-5 pb-5">
        <div class="text-white row">
            <div class="col-lg-8 col-md-8">
                <figure class="p-8 md:flex rounded-xl" style="background: #A3386D">
                    <img class="mx-auto w-55 rounded-2xl" src="<?php echo e(asset('img/thumb/gouv.jpeg')); ?>" alt="" width="384" height="512">
                    <div class="pt-6 mt-5 space-y-4 text-center">
                        <blockquote>
                        <p class="pl-3 pr-3 text-sm font-semibold text-left">
                            “Sous le patronnage de SEM Gentiny Ngobila Mbaka, Gouverneur de la ville de kinshasa”
                        </p>
                        </blockquote>
                        <figcaption class="font-medium">
                        <div class="font-bold text-cyan-600">
                            
                        </div>
                        </figcaption>
                    </div>
                    </figure>
            </div>

            <div class="col-lg-4 col-md-4">
                <div class="">
                    <div class="card-body">
                        <h5 class="card-title"><img src="<?php echo e(asset('img/thumb/logo.svg')); ?>" alt=""></h5>
                    </div>
                    </div>
            </div>
        </div>
    </div>
</div>

<div class="pt-5 pb-5">
    <div class="container pt-2 pb-2">
        <div class="row">
            <center><span class="text-3xl font-bold">Nos partenaires</span></center>
        </div><br><br>

        <div class="row">
            <div class="mb-4 col-lg-3 col-md-3">
                <div class="border-0 card">
                    <div class="card-body">
                        <div class="card-text">
                            <img src="<?php echo e(asset('img/thumb/apdnk.jpg')); ?>" alt="">
                        </div>
                    </div>
                </div>
            </div>

            <div class="mb-4 col-lg-3 col-md-3">
                <div class="border-0 card">
                    <div class="card-body">
                        <div class="card-text">
                            <img src="<?php echo e(asset('img/thumb/apdnk.jpg')); ?>" alt="">
                        </div>
                    </div>
                </div>
            </div>

            <div class="mb-4 col-lg-3 col-md-3">
                <div class="border-0 card">
                    <div class="card-body">
                        <div class="card-text">
                            <img src="<?php echo e(asset('img/thumb/apdnk.jpg')); ?>" alt="">
                        </div>
                    </div>
                </div>
            </div>

            <div class="mb-4 col-lg-3 col-md-3">
                <div class="border-0 card">
                    <div class="card-body">
                        <div class="card-text">
                            <img src="<?php echo e(asset('img/thumb/apdnk.jpg')); ?>" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tcvo5855/sites/KinTech-v2/resources/views/pages/home.blade.php ENDPATH**/ ?>