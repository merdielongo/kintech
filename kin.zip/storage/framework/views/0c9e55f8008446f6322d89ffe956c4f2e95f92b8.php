<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="mt-5 row">
        <div class="mt-5 col-lg-3 col-md-3 offset-lg-1 col-md-1">

            <div class="text-uppercase fs-2">
                <img src="<?php echo e(asset('img/thumb/Kintech_Plan de travail 1.jpg')); ?>" alt="" class="w-100">
            </div>

            <div class="mt-5 row">
                <a href="<?php echo e(route('home.register')); ?>" class="p-2 text-lg rounded-pill btn btn-primary">Inscrivez vous</a>
            </div>
        </div>

        <div class="mt-5 col-lg-6 col-md-6">
            <div class="p-5 border-0 card">
                <span class="fw-normal fs-5">KINTECH, première foire du numérique organisée par la ville de Kinshasa</span>
                <div class="mt-3 row">
                    <div class="col-lg-12">
                        <div class="row">
                            <div class="mb-4 col-lg-12 col-md-12">
                                <div>La ville de <b>Kinshasa</b> regorge de cerveaux,
                                    inventeurs, entrepreneurs, innovateurs et geeks. <br> <br>

                                    <b>Education</b> et enseignement, environnement, accès aux
                                    soins médicaux ou encore <b>digitalisation</b> des services publics. <br><br>
                                </div>
                            </div>

                            <div class="col-lg-12 col-md-12">

                                A L’ère du <b>digital</b>, il est désormais indispensable
                                d’investir plus d’efforts dans le <b>développement</b> du <b>numérique</b> au niveau régionale. <br><br>

                                La <b>ville</b> de <b>Kinshasa</b> souhaite proposer des solutions numériques
                                pour pallier aux problèmes rencontrés dans ces différents secteurs.

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="container mt-5 mb-4">
    <div class="mt-5 row">
        <div class="mt-5 col-lg-6 col-md-6">
            <span class="fw-normal fs-5">Visitez le salon et Rencontrez les décideurs du secteur numérique</span>
            <div class="mt-3 row">
                <div class="col-lg-12">
                    <div class="flex-row p-3 mb-2 border-0 card d-flex">
                        <div class="text-success fas fa-th fa-2x pe-4"></div>
                        <div class="fw-bold">Entreprises privées</div>
                    </div>

                    <div class="flex-row p-3 mb-2 border-0 card d-flex">
                        <div class="text-success fas fa-th fa-2x pe-4"></div>
                        <div class="fw-bold">Entreprises publiques.</div>
                    </div>

                    <div class="flex-row p-3 mb-2 border-0 card d-flex">
                        <div class="text-success fas fa-th fa-2x pe-4"></div>
                        <div class="fw-bold">Grands Investisseurs</div>
                    </div>

                    <div class="flex-row p-3 mb-2 border-0 card">
                        <div class="text-success fas fa-th fa-2x pe-4"></div>
                        <div class="fw-bold">Et actionnaires</div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-6 col-md-6 d-flex align-items-center">
            <div class="">
                <span class="fw-bold fs-3">Vous avez un projet numérique ?</span> <br>
                <span class=""><b>KINTECH</b> est l’évènement à ne pas manquer. <br> <br>
                Présentez vos idées devant un panel de décideurs en participant
                au concours KINTECH et tentez de remporter un soutien de la ville de Kinshasa</span> <br><br>

                <a href="<?php echo e(route('home.register')); ?>" class="p-2 btn btn-danger">Inscrivez-vous maintenant</a> <br><br>
                <a href="<?php echo e(route('home.program')); ?>">Découvrez le programme des journées.</a>
            </div>
        </div>

    </div>
</div>



<div class="pt-5 pb-5">
    <div class="container pt-2 pb-2">
        <div class="row">
            <center>
                <span>EDITION 2021</span> <br>
                <span class="text-3xl font-bold">Intervenants</span>
            </center>
        </div><br><br><br>

        <div class="row">
            <div class="mb-5 col-lg-3 col-md-3">
                <div id="card-intervenant">
                    <div class="border-0 card rounded-2xl">
                        <img style="height: 270px;" src="" class="card-img-top card rounded-2xl" alt="...">
                    </div>

                    <div class="mt-2 border-0 card rounded-2xl">
                        <div class="card-body">
                            <h5 class="font-bold text-center card-title">Christian Buehner</h5>
                            <p class="text-center card-text"><b>Expériences :</b> mon expérience + nombres d'années d'exercice </p>
                        </div>
                        <div class="p-1 rounded-b-2xl" style="background: #8D3D89"></div>
                        </div>
                </div>
            </div>

            <div class="mb-5 col-lg-3 col-md-3">
                <div id="card-intervenant">
                    <div class="border-0 card rounded-2xl">
                        <img style="height: 270px;" src="" class="card-img-top card rounded-2xl" alt="...">
                    </div>

                    <div class="mt-2 border-0 card rounded-2xl">
                        <div class="card-body">
                            <h5 class="font-bold text-center card-title">Christian Buehner</h5>
                            <p class="text-center card-text"><b>Expériences :</b> mon expérience + nombres d'années d'exercice </p>
                        </div>
                        <div class="p-1 rounded-b-2xl" style="background: #8D3D89"></div>
                        </div>
                </div>
            </div>

            <div class="mb-5 col-lg-3 col-md-3">
                <div id="card-intervenant">
                    <div class="border-0 card rounded-2xl">
                        <img style="height: 270px;" src="" class="card-img-top card rounded-2xl" alt="...">
                    </div>

                    <div class="mt-2 border-0 card rounded-2xl">
                        <div class="card-body">
                            <h5 class="font-bold text-center card-title">Christian Buehner</h5>
                            <p class="text-center card-text"><b>Expériences :</b> mon expérience + nombres d'années d'exercice </p>
                        </div>
                        <div class="p-1 rounded-b-2xl" style="background: #8D3D89"></div>
                        </div>
                </div>
            </div>

            <div class="mb-5 col-lg-3 col-md-3">
                <div id="card-intervenant">
                    <div class="border-0 card rounded-2xl">
                        <img style="height: 270px;" src="" class="card-img-top card rounded-2xl" alt="...">
                    </div>

                    <div class="mt-2 border-0 card rounded-2xl">
                        <div class="card-body">
                            <h5 class="font-bold text-center card-title">Christian Buehner</h5>
                            <p class="text-center card-text"><b>Expériences :</b> mon expérience + nombres d'années d'exercice </p>
                        </div>
                        <div class="p-1 rounded-b-2xl" style="background: #8D3D89"></div>
                        </div>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="pt-5 pb-5 mt-2">
    <div class="container">
        <div class="row">
            <center>
                <span>EDITION 2021</span> <br>
                <span class="text-3xl font-bold">Programme des activites</span>
            </center>
        </div><br> <br>

        <div class="row">
            <div class="col-lg-6 col-md-6">
                <div class="p-4 shadow-sm card">
                    <div class="mb-4 text-center fw-bold">
                        Jour 1 : Cérémonie d’ouverture, conférences présentation et concours.
                    </div>

                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">Heure</th>
                                <th scope="col">Activites</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>08h30 - 09h00</td>
                                <td>Arrivee et installation des invites</td>
                            </tr>
                            <tr>
                                <td>09h00 - 09h05</td>
                                <td>Hymne nationnale</td>
                            </tr>
                            <tr>
                                <td>09h05 - 09h15</td>
                                <td>Mot d'ouverture</td>
                            </tr>
                            <tr>
                                <td>09h15 - 10h00</td>
                                <td>Discours et divers</td>
                            </tr>
                            <tr>
                                <td>10h - 11h00</td>
                                <td>Cocktail d'ouverture + visite officielle de stands</td>
                            </tr>
                            <tr>
                                <td>11h00 - 11h15</td>
                                <td>installations des invites dans la salle de conferences</td>
                            </tr>
                            <tr>
                                <td>11h15 - 11h25</td>
                                <td>Mot d'introduction</td>
                            </tr>
                            <tr>
                                <td>11h25 - 12h25</td>
                                <td>Conference 1</td>
                            </tr>
                            <tr>
                                <td>1éh25 - 13h25</td>
                                <td>Conference 2</td>
                            </tr>
                            <tr>
                                <td>13h25 - 14h15</td>
                                <td>Pause</td>
                            </tr>
                            <tr>
                                <td>14h15 - 17h00</td>
                                <td>Presentation de projet et concours simultane</td>
                            </tr>
                            <tr>
                                <td>17h00</td>
                                <td>cloture de la premier journee</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="col-lg-6 col-md-6">

            <div class="p-4 shadow-sm card">
                <div class="mb-4 text-center fw-bold">
                    Jour 2 : Conférences, présentations, concours et clôture
                </div>

                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">Heure</th>
                            <th scope="col">Activites</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>08h30 - 09h00</td>
                            <td>Arrivee et installation des invites</td>
                        </tr>
                        <tr>
                            <td>09h00 - 09h05</td>
                            <td>Mot d'ouverture</td>
                        </tr>
                        <tr>
                            <td>09h05 - 10h05</td>
                            <td>Conference 3</td>
                        </tr>
                        <tr>
                            <td>10h05 - 11h05</td>
                            <td>Conference 4</td>
                        </tr>
                        <tr>
                            <td>11h05 - 11h35</td>
                            <td>Pause</td>
                        </tr>
                        <tr>
                            <td>11h35 - 13h25</td>
                            <td>Presentation de projet et concours simultane</td>
                        </tr>
                        <tr>
                            <td>13h35 - 14h15</td>
                            <td>Pause et deliberation</td>
                        </tr>
                        <tr>
                            <td>14h15 - 15h00</td>
                            <td>Ceremonie de cloture</td>
                        </tr>
                        <tr>
                            <td>15h00 - 15h40</td>
                            <td>Cocktail de cloture</td>
                        </tr>
                        <tr>
                            <td>15h40</td>
                            <td>Fin de l'evenement</td>
                        </tr>
                    </tbody>
                </table>
            </div>
            </div>
        </div>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kintech-v2\resources\views/pages/event.blade.php ENDPATH**/ ?>