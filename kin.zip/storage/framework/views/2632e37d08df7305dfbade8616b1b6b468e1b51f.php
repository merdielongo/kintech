<?php $__env->startSection('content'); ?>

<div class="container mt-5">
    <?php echo Form::open(); ?>

    <div class="p-5 shadow-sm row card">
        <center><h5 class="fw-bold">Formulaire d'enregistrement du projet</h5></center>

        <div class="mt-5 row">
            <div class="mb-3 form-group col-lg-4">
                <b><?php echo Form::label('Nom de l\'entreprise'); ?></b>
                <?php echo Form::text('name', null, ['class'=> 'form-control']); ?>

            </div>

            <div class="mb-3 form-group col-lg-4">
                <b><?php echo Form::label('Nom projet'); ?></b>
                <?php echo Form::text('project', null, ['class'=> 'form-control']); ?>

            </div>

            <div class="mb-3 form-group col-lg-4">
                <b><?php echo Form::label('Personne en charge du projet'); ?></b>
                <?php echo Form::text('project', null, ['class'=> 'form-control']); ?>

            </div>

            <div class="mb-3 form-group col-lg-4">
                <b><?php echo Form::label('Secteur d\'activite'); ?></b>
                <?php echo Form::text('project', null, ['class'=> 'form-control']); ?>

            </div>

            <div class="mb-3 form-group col-lg-4">
                <b><?php echo Form::label('Adresse email'); ?></b>
                <?php echo Form::text('project', null, ['class'=> 'form-control']); ?>

            </div>

            <div class="mb-3 form-group col-lg-4">
                <b><?php echo Form::label('Numero de telephone'); ?></b>
                <?php echo Form::text('project', null, ['class'=> 'form-control']); ?>

            </div>

            <div class="mb-3 form-group col-lg-4">
                <b><?php echo Form::label('Adresse de l\'entreprise'); ?></b>
                <?php echo Form::text('project', null, ['class'=> 'form-control']); ?>

            </div>

            <div class="mb-3 form-group col-lg-4">
                <b><?php echo Form::label('Site internet'); ?></b>
                <?php echo Form::text('project', null, ['class'=> 'form-control']); ?>

            </div>

            <div class="mb-3 form-group col-lg-4">
                <b><?php echo Form::label('Pages '); ?></b>
                <?php echo Form::text('project', null, ['class'=> 'form-control']); ?>

            </div>

            <div class="mb-3 form-group col-lg-4">
                <b><?php echo Form::label('Photocopie de la pièce d’identité. '); ?></b>
                <?php echo Form::file('project', ['class'=> 'form-control']); ?>

            </div>

            <div class="mb-3 form-group col-lg-4">
                <b><?php echo Form::label('Présentation complète du projet en PDF.'); ?></b>
                <?php echo Form::file('project', ['class'=> 'form-control']); ?>

            </div>

            <div class="mb-3 form-group col-lg-4">
                <b><?php echo Form::label('Business plan du projet'); ?></b>
                <?php echo Form::file('project', ['class'=> 'form-control']); ?>

            </div>
        </div>

        <div class="mt-4 row">
            <?php echo Form::submit('Envoyer le formulaire', ['class'=>'btn btn-danger col-lg-4 col-md-4']); ?>

        </div>

    </div>
    <?php echo Form::close(); ?>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tcvo5855/sites/KinTech-v2/resources/views/pages/project.blade.php ENDPATH**/ ?>